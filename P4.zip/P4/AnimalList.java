package P4;

import java.io.Serializable;
import java.util.Iterator;

public class AnimalList implements Iterable<Animal>, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int size = 0;
	private AnimalNode <Animal> head = null, tail = null;
	public int size()
	{
		return size;
	}
	public boolean isEmpty()
	{
		if(size == 0)
			return true;
		else
			return false;
	}
	public void addFirst(Animal animal)
	{
		AnimalNode<Animal> n = new AnimalNode<Animal>(animal);
		if(isEmpty())
		{
			head = tail = n;
		}
		else
		{
			n.next = head;
			head = n;
		}
		size++;
	}
	public void addLast(Animal animal)
	{
		AnimalNode<Animal> n = new AnimalNode<Animal>(animal);
		if(tail == null)
			head = tail = n;
		else
		{
			tail.next = n;
			tail = tail.next;
		}
		size++;
	}
	public void add(int index, Animal animal)
	{
		if(index < 0 || index >= size)
			throw new IndexOutOfBoundsException();
		else if(index == 0)
			addFirst(animal);
		else if(index == size)
			addLast(animal);
		else
		{
			AnimalNode<Animal> n = new AnimalNode<>(animal);
			AnimalNode<Animal> curr = head;
			for(int i = 0; i < index-1; i++)
				curr = curr.next;
			n.next = curr.next;
			curr.next = n;
			size++;

		}

	}
	public Animal removeFirst()
	{
		if(head == null)
			return null;
		AnimalNode<Animal> temp = head;
		head = head.next;
		if(head == null)
			tail = null;
		size--;
		return temp.element;
	}
	public Animal removeLast()
	{
		if(tail == null)
			return null;
		else if(size == 1)
			return removeFirst();
		else
		{
			AnimalNode <Animal> temp = tail;
			AnimalNode <Animal> prev = head;
			for(int i = 0; i < size-2; i++)
			{
				prev = prev.next;
			}
			tail = prev;
			tail.next = null;
			size--;
			return temp.element;
		}
	}
	public Animal remove(int index)
	{
		if(index < 0 || index >= size)
			throw new IndexOutOfBoundsException();
		else if(index == 0)
			return removeFirst();
		else if(index == size-1)
		{
			return removeLast();
		}
		else
		{
			AnimalNode<Animal> prev = head;
			for(int i = 0; i < index-1; i++)
			{
				prev = prev.next;
			}
			AnimalNode<Animal> curr = prev.next;
			prev.next = curr.next;
			size--;
			return curr.element;
		}
	}
	
	//GET AND SET
	public Animal getFirst()
	{
		if(size == 0)
			return null;
		else
			return head.element;
	}
	public Animal getLast()
	{
		if(size == 0)
			return null;
		else
			return tail.element;
	}
	public Animal get(int index)
	{
		if(index < 0 || index >= size)
			throw new IndexOutOfBoundsException();
		else if(index == 0)
			return getFirst();
		else if(index == size-1)
			return getLast();
		else
		{
			AnimalNode<Animal>curr = head;
			for(int i = 0; i < index; i++)
			{
				curr = curr.next;
			}
			return curr.element;
		}
	}
	public Animal set(int index, Animal animal)
	{
		if(index < 0 || index >= size)
			throw new IndexOutOfBoundsException();
		else
		{
			AnimalNode<Animal>curr = head;
			for(int i = 0; i < index; i++)
			{
				curr = curr.next;
			}
			curr.element = animal;
			return curr.element;
		}
	}
	
	//to String
	public String toString()
	{
		AnimalNode<Animal> temp = head;
		String print = "";
		for(int i = 0; i < size; i++)
		{
			Animal curr = temp.element;
			print += curr.toString() + "\n";
			temp = temp.next;
		}
		return print;
	}
	
	//INNER AnimalNode CLASS
	private static class AnimalNode<E> implements Serializable{
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		Animal element;
		AnimalNode <Animal> next;
		public AnimalNode(Animal e)
		{
			element = e;
		}
	}

	@Override
	public Iterator<Animal> iterator() {
		return new MyIterator();
	}
	
	private class MyIterator implements Iterator<Animal>{
		private AnimalNode <Animal> current = head;
		@Override
		public boolean hasNext() {
			return (current != null);
		}

		@Override
		public Animal next() {
			Animal a = current.element;
			current = current.next;
			return a;
		}
		

	}
	
	//P4 Methods
	public AnimalList getHungryAnimals()
	{
		AnimalList hungry = new AnimalList();
		AnimalNode<Animal> curr = head;
		for(int i = 0; i < size; i++)
		{
			if(curr.element.getEnergy() < 50)
			{
				hungry.addLast(curr.element);
			}
			curr = curr.next;
		}
		if(hungry.size() == 0)
		{			
			return null;
		}
		else
			return hungry;
		
	}
	
	public AnimalList getStarvingAnimals()
	{
		AnimalList starving = new AnimalList();
		AnimalNode<Animal> curr = head;
		for(int i = 0; i < size; i++)
		{
			if(curr.element.getEnergy() < 17)
			{
				starving.addLast(curr.element);
			}
			curr = curr.next;
		}
		if(starving.size() == 0)
		{			
			return null;
		}
		else
			return starving;
	}
	
	public double getRequiredFood()
	{
		AnimalNode<Animal> curr = head;
		double requiredFood = 0.0;
		for(int i = 0; i < size; i++)
		{
			requiredFood += (100 - curr.element.getEnergy());
			curr = curr.next;
		}
		return requiredFood;
	}
	
	public AnimalList getAnimalsInBarn()
	{
		AnimalNode<Animal> curr = head;
		AnimalList inBarn = new AnimalList();
		for(int i = 0; i < size; i++)
		{
			Animal temp = curr.element;
			if(temp.getX() > 450 && temp.getX() < 550)
			{
				if(temp.getY() > 50 && temp.getY() < 150)
				{
					inBarn.addLast(temp);
				}
			}
			curr = curr.next;
		}
		
		if(inBarn.size() == 0)
			return null;
		else
			return inBarn;
	}
	
	public AnimalList getByType(Class<?> animalType)
	{
		AnimalList type = new AnimalList();
		AnimalNode<Animal> curr = head;
		for(int i = 0; i < size(); i++)
		{
			if(curr.element.getClass().equals(animalType))
			{
				type.addLast(curr.element);
			}
			curr = curr.next;
		}
		return type;
	}
	
		
}
